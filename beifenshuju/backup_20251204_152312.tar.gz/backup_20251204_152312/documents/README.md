# Enterprise Brain - 企业级业务管理系统

## 📋 项目简介-周辉3

这是一个基于Vue 3 + Element Plus的企业级业务管理系统，同时包含基于UniApp的移动端版本。集成了完整的业务管理功能，为企业提供全平台的业务管理解决方案。

[![Powered by CloudBase](https://7463-tcb-advanced-a656fc-1257967285.tcb.qcloud.la/mcp/powered-by-cloudbase-badge.svg)](https://github.com/TencentCloudBase/CloudBase-AI-ToolKit)

> 本项目基于 [**CloudBase AI ToolKit**](https://github.com/TencentCloudBase/CloudBase-AI-ToolKit) 开发，通过AI提示词和 MCP 协议+云开发，让开发更智能、更高效，支持AI生成全栈代码、一键部署至腾讯云开发（免服务器）、智能日志修复。

## 🎯 核心功能模块

### 📊 PC端功能模块

#### 🏢 项目与设计管理
- **ProjectManagement.vue** - 研发项目管理
  - 项目统计看板
  - 项目列表管理
  - 项目甘特图可视化
  - 项目详情跟踪

#### 🎨 设计管理
- **DesignManagement.vue** - 设计管理
  - 设计文件管理
  - 设计版本控制
  - 设计评审流程
  - 设计预览功能

#### 📄 文档管理
- **DocumentManagement.vue** - 文档管理
  - 文档上传下载
  - 文档版本管理
  - 文档预览
  - 批量操作

#### 🔄 版本控制
- **VersionControl.vue** - 版本控制
  - Git版本管理
  - 分支管理
  - 提交历史
  - 代码审查

#### 📝 售后服务管理
- **AfterSalesList.vue** - 售后工单管理
- **CustomerFeedback.vue** - 客户反馈管理
- **ReturnProcessing.vue** - 退货处理
- **WarrantyManagement.vue** - 保修管理
- **ComplaintManagement.vue** - 投诉管理

#### 🔧 工艺工程管理
- **ProcessDesign.vue** - 工艺设计
- **FixtureDesign.vue** - 夹具设计
- **ToolingDesign.vue** - 工装设计
- **ProcessOptimization.vue** - 工艺优化
- **StandardOperation.vue** - 标准作业

#### 🤖 AI智能分析
- **AIDashboard.vue** - AI智能分析中心
  - AI模型管理
  - 异常检测
  - 预测分析
  - 智能建议

#### 👥 人力资源管理
- **HRDashboard.vue** - 人力资源管理
  - 员工管理
  - 考勤管理
  - 薪资管理
  - 绩效评估

#### 📦 库存管理
- **InventoryList.vue** - 库存管理
  - 商品库存跟踪
  - 库存预警
  - 库存调整
  - 批量操作

#### 🛠️ 通用组件
- **CellRenderer.vue** - 表格单元格渲染器
- **ColumnManager.vue** - 列管理器
- **FormulaEditor.vue** - 公式编辑器
- **Breadcrumb.vue** - 面包屑导航
- **Pagination.vue** - 分页组件
- **SearchInput.vue** - 搜索输入组件

### 📱 移动端功能模块

#### 🛍️ 库存管理
- **ScanIn.vue** - 入库扫描
- **ScanOut.vue** - 出库扫描
- **LocationScan.vue** - 位置扫描
- **StockCheck.vue** - 库存盘点
- **ScanShipping.vue** - 发货扫描

#### 🏭 生产管理
- **WorkReport.vue** - 工作报告
- **DefectReport.vue`** - 缺陷报告

#### ⏰ 考勤管理
- **ClockIn.vue** - 打卡签到

#### 💰 薪资管理
- **MobilePayroll.vue** - 移动端薪资查询

## 🛠️ 技术栈

### PC端
- **Vue 3** - 渐进式JavaScript框架
- **TypeScript** - JavaScript的超集，提供类型支持
- **Element Plus** - 基于Vue 3的组件库
- **Vite** - 新一代前端构建工具
- **Vue Router** - Vue官方路由管理器

### 移动端
- **UniApp** - 跨平台开发框架
- **Vue 2/3** - 支持Vue 2和Vue 3语法
- **Vant UI** - 轻量、可靠的移动端Vue组件库
- **uView UI** - 全面兼容nvue的uni-app生态框架

### 后端
- **腾讯云开发（CloudBase）** - 无服务器云开发平台
- **云函数** - 无需服务器的后端逻辑
- **云数据库** - 文档型NoSQL数据库
- **云存储** - 对象存储服务

## 🚀 快速开始

### 环境要求
- Node.js 16+
- npm 或 yarn
- HBuilderX（推荐，用于UniApp开发）

### 安装依赖
```bash
# PC端
cd 07-frontend
npm install
npm run dev

# 移动端
cd platforms/mobile
npm install
```

### 开发环境运行
```bash
# PC端开发服务器
cd 07-frontend
npm run dev

# 移动端开发（HBuilderX）
# 1. 使用HBuilderX打开项目
# 2. 点击运行 -> 运行到浏览器/H5端
# 3. 或运行到手机模拟器/真机
```

### 生产环境部署
```bash
# PC端构建
cd 07-frontend
npm run build

# 移动端打包
# 在HBuilderX中选择 发行 -> 原生App-云打包 或 H5发行
```

## 📱 移动端适配

本项目移动端已适配以下平台：
- ✅ **H5** - 浏览器端
- ✅ **微信小程序**
- ✅ **支付宝小程序**
- ✅ **抖音小程序**
- ✅ **App (iOS/Android)**

## 🌐 云开发部署

1. 注册腾讯云账号
2. 开通云开发服务
3. 创建云开发环境
4. 配置云函数和数据库
5. 部署静态资源

## 🤝 贡献指南

1. Fork 本仓库
2. 创建你的特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交你的修改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 打开一个 Pull Request

## 📄 许可证

本项目采用 MIT 许可证 查看 [LICENSE](LICENSE) 文件了解详情

## 📞 联系方式

- 项目链接：[https://gitcode.com/sardenesy/enterprise-brain](https://gitcode.com/sardenesy/enterprise-brain)
- 项目主页：[https://sardenesy.github.io/enterprise-brain](https://sardenesy.github.io/enterprise-brain)

---

⭐ 如果这个项目对你有帮助，请给个星标支持一下！
