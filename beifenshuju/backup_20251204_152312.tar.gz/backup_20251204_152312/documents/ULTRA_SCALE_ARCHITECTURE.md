# 万人企业级超大规模系统架构方案

## 🎯 系统定位

**规模**：支持10,000+用户同时在线  
**平台**：全平台覆盖（PC、移动端、平板、工控）  
**性能**：高并发、高可用、高扩展  
**架构**：微服务 + 分布式 + 云原生

---

## 📋 目录

1. [技术架构](#技术架构)
2. [数据库架构](#数据库架构)
3. [部署架构](#部署架构)
4. [性能优化](#性能优化)
5. [实施路线图](#实施路线图)

---

## 技术架构

### 整体架构图

```
┌─────────────────────────────────────────────────────────────────────────┐
│                            客户端层 (多平台)                              │
│  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐      │
│  │ Windows │  │  Linux  │  │  macOS  │  │ HarmonyOS│  │Android/ │      │
│  │   PC    │  │   PC    │  │   PC    │  │    PC   │  │   iOS   │      │
│  └─────────┘  └─────────┘  └─────────┘  └─────────┘  └─────────┘      │
│                        ↓  PWA + Electron + 移动应用  ↓                   │
└─────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                          CDN / 反向代理层                                │
│            Nginx / Traefik (负载均衡 + SSL终止 + 静态资源)               │
└─────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                          API 网关层 (Kong / APISIX)                      │
│  路由、认证、限流、熔断、监控、日志、协议转换、API聚合                    │
└─────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                          微服务应用层                                     │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐     │
│  │用户服务  │ │物料服务  │ │BOM服务   │ │订单服务  │ │库存服务  │     │
│  │(Node.js) │ │(Java)    │ │(Java)    │ │(Java)    │ │(Go)      │     │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘     │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐     │
│  │生产服务  │ │财务服务  │ │报表服务  │ │消息服务  │ │文件服务  │     │
│  │(Java)    │ │(Java)    │ │(Python)  │ │(Node.js) │ │(Go)      │     │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘     │
└─────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                          中间件层                                        │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐     │
│  │消息队列  │ │分布式缓存│ │搜索引擎  │ │任务调度  │ │服务注册  │     │
│  │RabbitMQ  │ │Redis     │ │ES        │ │XXL-Job   │ │Consul    │     │
│  │Kafka     │ │Cluster   │ │          │ │          │ │Nacos     │     │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘     │
└─────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                          数据存储层                                       │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐     │
│  │PostgreSQL│ │MongoDB   │ │ClickHouse│ │MinIO     │ │Backup    │     │
│  │(主业务)  │ │(日志文档)│ │(OLAP)    │ │(对象存储)│ │(备份)    │     │
│  │Cluster   │ │          │ │          │ │          │ │          │     │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘     │
└─────────────────────────────────────────────────────────────────────────┘
                                    ↓
┌─────────────────────────────────────────────────────────────────────────┐
│                          监控运维层                                       │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐     │
│  │Prometheus│ │Grafana   │ │ELK       │ │Jaeger    │ │SkyWalking│     │
│  │(指标)    │ │(可视化)  │ │(日志)    │ │(链路)    │ │(APM)     │     │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘     │
└─────────────────────────────────────────────────────────────────────────┘
```

### 前端架构（全平台支持）

```
┌─────────────────────────────────────────────────────────────────┐
│                         前端技术栈                              │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  ┌──────────────────────────────────────────────────────┐      │
│  │          PC端 (Windows/Linux/macOS/HarmonyOS)        │      │
│  │                                                       │      │
│  │  方案1: Web应用 (PWA)                                 │      │
│  │    - Vue 3 + Vite                                    │      │
│  │    - 支持离线工作                                     │      │
│  │    - 自适应响应式                                     │      │
│  │                                                       │      │
│  │  方案2: Electron桌面应用                              │      │
│  │    - 跨平台原生体验                                   │      │
│  │    - 本地文件访问                                     │      │
│  │    - 系统托盘集成                                     │      │
│  └──────────────────────────────────────────────────────┘      │
│                                                                 │
│  ┌──────────────────────────────────────────────────────┐      │
│  │          移动端 (Android/iOS/HarmonyOS)              │      │
│  │                                                       │      │
│  │  方案1: Uni-App (已有基础)                            │      │
│  │    - 一套代码多端发布                                 │      │
│  │    - 原生性能                                         │      │
│  │    - 丰富组件库                                       │      │
│  │                                                       │      │
│  │  方案2: React Native (可选)                           │      │
│  │    - Facebook生态                                     │      │
│  │    - 热更新支持                                       │      │
│  │                                                       │      │
│  │  方案3: Flutter (推荐)                                │      │
│  │    - 高性能渲染                                       │      │
│  │    - 统一UI体验                                       │      │
│  │    - 编译为原生代码                                   │      │
│  └──────────────────────────────────────────────────────┘      │
│                                                                 │
│  ┌──────────────────────────────────────────────────────┐      │
│  │          平板/工控面板                                │      │
│  │                                                       │      │
│  │  - 响应式Web应用                                      │      │
│  │  - 触摸优化                                           │      │
│  │  - 大字体模式                                         │      │
│  │  - 简化操作流程                                       │      │
│  └──────────────────────────────────────────────────────┘      │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### 技术选型详解

#### 后端技术栈

```yaml
微服务框架:
  核心业务: Spring Boot 3.x + Spring Cloud Alibaba
  高性能服务: Go (Gin/Echo框架)
  实时服务: Node.js (Express/NestJS)
  数据分析: Python (FastAPI)

服务治理:
  服务注册发现: Nacos / Consul
  配置中心: Nacos / Apollo
  服务网格: Istio (可选)
  API网关: Kong / APISIX

消息中间件:
  核心业务: RabbitMQ (可靠性)
  大数据流: Kafka (高吞吐)
  实时通知: WebSocket + Redis Pub/Sub

缓存:
  分布式缓存: Redis Cluster
  本地缓存: Caffeine
  缓存策略: 多级缓存

任务调度:
  定时任务: XXL-Job / Quartz
  分布式任务: Elastic-Job
```

#### 数据库架构（重点）

```yaml
关系型数据库 (PostgreSQL):
  版本: PostgreSQL 14+
  部署: 主从复制 + 读写分离
  分片: Citus扩展 (支持百TB数据)
  备份: pg_basebackup + WAL归档
  
  集群配置:
    - 1个主节点 (写入)
    - 3个从节点 (读取)
    - 1个备份节点 (灾难恢复)
  
  性能优化:
    - 分区表 (按时间/业务分区)
    - 物化视图 (报表加速)
    - 索引优化 (B-tree, GIN, BRIN)
    - 连接池 (PgBouncer)

NoSQL数据库 (MongoDB):
  用途: 日志、文档、非结构化数据
  部署: 副本集 + 分片集群
  
  场景:
    - 操作日志存储
    - 审计记录
    - 用户行为分析
    - 灵活schema数据

OLAP数据库 (ClickHouse):
  用途: 大数据分析、报表
  特点: 列式存储、极速查询
  
  场景:
    - 实时数据分析
    - 销售报表
    - 生产统计
    - BI看板

对象存储 (MinIO):
  用途: 文件、图片、附件
  部署: 分布式集群
  容量: PB级扩展
```

---

## 数据库架构

### PostgreSQL集群架构

```
                         ┌─────────────────┐
                         │   PgBouncer     │  连接池
                         │  (端口: 6432)    │
                         └────────┬────────┘
                                  │
                 ┌────────────────┼────────────────┐
                 │                │                │
        ┌────────▼────────┐  ┌───▼────────┐  ┌───▼────────┐
        │   主数据库       │  │  从数据库1  │  │  从数据库2  │
        │  (写入+读取)     │  │  (只读)     │  │  (只读)     │
        │  PostgreSQL      │  │ PostgreSQL │  │ PostgreSQL │
        │  Port: 5432      │  │ Port: 5432 │  │ Port: 5432 │
        └────────┬────────┘  └───┬────────┘  └───┬────────┘
                 │流复制          │流复制          │流复制
                 │                │                │
        ┌────────▼────────────────▼────────────────▼────────┐
        │              共享存储 (NFS/Ceph)                   │
        │           WAL归档 + 备份文件                       │
        └────────────────────────────────────────────────────┘
                                  │
                         ┌────────▼────────┐
                         │   从数据库3     │  备份节点
                         │   (灾难恢复)    │  异地机房
                         │   PostgreSQL    │
                         └─────────────────┘
```

### 数据分片策略

#### 方案1: Citus扩展（推荐万人企业）

```sql
-- 安装Citus扩展
CREATE EXTENSION citus;

-- 添加工作节点
SELECT citus_add_node('worker-1.example.com', 5432);
SELECT citus_add_node('worker-2.example.com', 5432);
SELECT citus_add_node('worker-3.example.com', 5432);

-- 创建分布式表
CREATE TABLE sales_orders (
    id BIGSERIAL,
    order_code VARCHAR(50),
    customer_id BIGINT,  -- 分片键
    order_date DATE,
    amount DECIMAL(15,2),
    -- ... 其他字段
    PRIMARY KEY (customer_id, id)
);

-- 分布表（按customer_id分片）
SELECT create_distributed_table('sales_orders', 'customer_id');

-- 创建引用表（小表，复制到所有节点）
CREATE TABLE products (
    id BIGSERIAL PRIMARY KEY,
    product_code VARCHAR(50),
    product_name VARCHAR(200)
);
SELECT create_reference_table('products');
```

#### 方案2: 应用层分片（更灵活）

```javascript
// backend/services/sharding/ShardingService.js
class ShardingService {
  constructor() {
    // 4个数据库分片
    this.shards = [
      new Pool({ host: 'shard-1.db', database: 'enterprise_brain_1' }),
      new Pool({ host: 'shard-2.db', database: 'enterprise_brain_2' }),
      new Pool({ host: 'shard-3.db', database: 'enterprise_brain_3' }),
      new Pool({ host: 'shard-4.db', database: 'enterprise_brain_4' })
    ];
  }

  // 根据客户ID计算分片
  getShardByCustomerId(customerId) {
    const shardIndex = customerId % this.shards.length;
    return this.shards[shardIndex];
  }

  // 根据订单编码计算分片
  getShardByOrderCode(orderCode) {
    const hash = this.hashCode(orderCode);
    const shardIndex = Math.abs(hash) % this.shards.length;
    return this.shards[shardIndex];
  }

  hashCode(str) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return hash;
  }

  // 查询所有分片（用于报表）
  async queryAllShards(sql, params) {
    const results = await Promise.all(
      this.shards.map(shard => shard.query(sql, params))
    );
    // 合并结果
    return results.flatMap(r => r.rows);
  }
}

module.exports = new ShardingService();
```

### 数据表设计（万人企业级）

```sql
-- ============================================
-- 用户相关表
-- ============================================

-- 用户表（分片：按用户ID模10000）
CREATE TABLE users (
    id BIGSERIAL PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100),
    phone VARCHAR(20),
    -- ... 其他字段
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    version INTEGER DEFAULT 0  -- 乐观锁
) PARTITION BY HASH (id);

-- 创建10个分区
CREATE TABLE users_0 PARTITION OF users FOR VALUES WITH (MODULUS 10, REMAINDER 0);
CREATE TABLE users_1 PARTITION OF users FOR VALUES WITH (MODULUS 10, REMAINDER 1);
-- ... users_2 到 users_9

-- ============================================
-- 业务核心表
-- ============================================

-- 销售订单表（分区：按年月）
CREATE TABLE sales_orders (
    id BIGSERIAL,
    order_code VARCHAR(50) UNIQUE NOT NULL,
    customer_id BIGINT NOT NULL,
    order_date DATE NOT NULL,
    amount DECIMAL(15,2),
    status VARCHAR(20),
    -- ... 其他字段
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id, order_date)
) PARTITION BY RANGE (order_date);

-- 按月分区（每月一个分区）
CREATE TABLE sales_orders_2024_01 PARTITION OF sales_orders
    FOR VALUES FROM ('2024-01-01') TO ('2024-02-01');
CREATE TABLE sales_orders_2024_02 PARTITION OF sales_orders
    FOR VALUES FROM ('2024-02-01') TO ('2024-03-01');
-- ... 继续创建

-- 物料表（不分区，使用索引优化）
CREATE TABLE materials (
    id BIGSERIAL PRIMARY KEY,
    material_code VARCHAR(50) UNIQUE NOT NULL,
    material_name VARCHAR(200) NOT NULL,
    category_id BIGINT,
    price DECIMAL(15,2),
    stock_quantity INTEGER DEFAULT 0,
    -- ... 其他字段
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    deleted BOOLEAN DEFAULT FALSE  -- 软删除
);

-- 创建索引
CREATE INDEX idx_materials_code ON materials(material_code) WHERE deleted = FALSE;
CREATE INDEX idx_materials_name ON materials USING GIN(to_tsvector('chinese', material_name));
CREATE INDEX idx_materials_category ON materials(category_id) WHERE deleted = FALSE;

-- ============================================
-- 审计日志表（MongoDB）
-- ============================================

-- 使用MongoDB存储（JSON格式）
{
  "_id": ObjectId("..."),
  "user_id": 12345,
  "action": "UPDATE",
  "table": "materials",
  "record_id": 67890,
  "changes": {
    "price": {"old": 100.00, "new": 120.00},
    "stock": {"old": 50, "new": 45}
  },
  "ip": "192.168.1.100",
  "timestamp": ISODate("2025-01-30T10:30:00Z")
}

-- ============================================
-- 统计报表表（ClickHouse）
-- ============================================

-- ClickHouse表（列式存储，超高性能）
CREATE TABLE sales_stats (
    date Date,
    product_id UInt64,
    customer_id UInt64,
    quantity UInt32,
    amount Decimal(15, 2),
    created_at DateTime
) ENGINE = MergeTree()
PARTITION BY toYYYYMM(date)
ORDER BY (date, product_id, customer_id);
```

### 缓存架构

```
┌─────────────────────────────────────────────────────────────┐
│                      多级缓存架构                           │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  L1: 本地缓存 (Caffeine)                                   │
│      - 热点数据 (用户信息、权限)                            │
│      - TTL: 5分钟                                           │
│      - 容量: 1000条                                         │
│                          ↓ 未命中                           │
│  L2: 分布式缓存 (Redis Cluster)                            │
│      - 共享数据 (物料、BOM)                                 │
│      - TTL: 1小时                                           │
│      - 容量: 无限                                           │
│                          ↓ 未命中                           │
│  L3: 数据库 (PostgreSQL)                                   │
│      - 持久化数据                                           │
│      - 读从库，写主库                                       │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 部署架构

### Kubernetes集群部署（生产环境）

```yaml
# k8s-deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: material-service
  namespace: enterprise-brain
spec:
  replicas: 10  # 10个副本应对高并发
  selector:
    matchLabels:
      app: material-service
  template:
    metadata:
      labels:
        app: material-service
    spec:
      containers:
      - name: material-service
        image: enterprise-brain/material-service:v1.0.0
        ports:
        - containerPort: 8080
        resources:
          requests:
            memory: "512Mi"
            cpu: "500m"
          limits:
            memory: "2Gi"
            cpu: "2000m"
        env:
        - name: SPRING_PROFILES_ACTIVE
          value: "production"
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: db-secret
              key: url
        livenessProbe:
          httpGet:
            path: /actuator/health
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /actuator/health/readiness
            port: 8080
          initialDelaySeconds: 30
          periodSeconds: 5
---
apiVersion: v1
kind: Service
metadata:
  name: material-service
  namespace: enterprise-brain
spec:
  selector:
    app: material-service
  ports:
  - port: 8080
    targetPort: 8080
  type: ClusterIP
---
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: material-service-hpa
  namespace: enterprise-brain
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: material-service
  minReplicas: 10
  maxReplicas: 50  # 最多50个副本
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
```

### 服务器配置建议

#### 生产环境（10,000用户）

```yaml
硬件配置:
  
  API网关集群 (3台):
    CPU: 16核
    内存: 32GB
    磁盘: 500GB SSD
    网络: 10Gbps
    成本: ¥3,000/台/月
  
  微服务集群 (20台):
    CPU: 32核
    内存: 64GB
    磁盘: 1TB SSD
    网络: 10Gbps
    成本: ¥6,000/台/月
  
  数据库集群 (5台):
    主库 (1台):
      CPU: 64核
      内存: 256GB
      磁盘: 4TB NVMe SSD
      成本: ¥15,000/月
    
    从库 (3台):
      CPU: 32核
      内存: 128GB
      磁盘: 2TB NVMe SSD
      成本: ¥8,000/台/月
    
    备份节点 (1台):
      CPU: 32核
      内存: 128GB
      磁盘: 10TB HDD
      成本: ¥5,000/月
  
  Redis集群 (6台):
    CPU: 16核
    内存: 64GB (全部用于缓存)
    磁盘: 500GB SSD
    成本: ¥4,000/台/月
  
  消息队列 (3台):
    CPU: 16核
    内存: 32GB
    磁盘: 2TB SSD
    成本: ¥3,500/台/月
  
  对象存储 (MinIO 4台):
    CPU: 8核
    内存: 16GB
    磁盘: 20TB HDD
    成本: ¥2,500/台/月
  
  监控服务器 (2台):
    CPU: 16核
    内存: 32GB
    磁盘: 2TB SSD
    成本: ¥3,000/台/月

总计成本:
  服务器: ¥250,000/月
  带宽: ¥50,000/月 (1Gbps专线)
  运维: ¥80,000/月 (4人团队)
  
  月度总成本: ¥380,000
  年度总成本: ¥4,560,000
```

### 网络拓扑

```
                    互联网
                      │
          ┌───────────┴───────────┐
          │                       │
     ┌────▼────┐            ┌────▼────┐
     │ 电信    │            │ 联通    │  多线接入
     │ 100Mbps│            │ 100Mbps │
     └────┬────┘            └────┬────┘
          │                       │
          └───────────┬───────────┘
                      │
          ┌───────────▼───────────┐
          │    DNS + CDN          │  加速静态资源
          │   (阿里云/腾讯云)      │
          └───────────┬───────────┘
                      │
          ┌───────────▼───────────┐
          │  负载均衡 (SLB)       │  4层负载
          │  (主备模式)           │
          └───────────┬───────────┘
                      │
          ┌───────────▼───────────┐
          │  Nginx集群 (3台)      │  7层负载 + SSL
          │  (Keepalived HA)      │
          └───────────┬───────────┘
                      │
          ┌───────────▼───────────┐
          │  API网关 (Kong)       │  鉴权 + 限流
          │  (集群模式)           │
          └───────────┬───────────┘
                      │
          ┌───────────▼───────────┐
          │  Kubernetes集群       │  容器编排
          │  (50+ Pods)           │
          └───────────┬───────────┘
                      │
    ┌─────────────────┼─────────────────┐
    │                 │                 │
┌───▼───┐        ┌───▼───┐        ┌───▼───┐
│微服务 │        │ 缓存  │        │数据库 │
│Pod群  │        │Redis  │        │PG集群 │
└───────┘        └───────┘        └───────┘
```

---

## 性能优化

### 并发性能指标

```yaml
目标性能指标 (10,000在线用户):
  
  并发请求:
    峰值QPS: 50,000 req/s
    平均QPS: 20,000 req/s
    最大并发连接: 50,000
  
  响应时间:
    P50: < 50ms
    P95: < 200ms
    P99: < 500ms
  
  数据库:
    读操作: < 10ms
    写操作: < 50ms
    事务吞吐: 10,000 TPS
  
  缓存:
    命中率: > 95%
    响应时间: < 1ms
  
  可用性:
    年可用性: 99.99% (年停机 < 53分钟)
    RTO: < 5分钟 (恢复时间)
    RPO: < 30秒 (数据丢失)
```

### 性能优化策略

#### 1. 数据库优化

```sql
-- 创建高效索引
CREATE INDEX CONCURRENTLY idx_orders_customer_date 
ON sales_orders(customer_id, order_date DESC) 
WHERE status != 'deleted';

-- 物化视图（报表加速）
CREATE MATERIALIZED VIEW mv_sales_summary AS
SELECT 
    DATE_TRUNC('day', order_date) AS date,
    customer_id,
    SUM(amount) AS total_amount,
    COUNT(*) AS order_count
FROM sales_orders
WHERE order_date >= CURRENT_DATE - INTERVAL '90 days'
GROUP BY DATE_TRUNC('day', order_date), customer_id;

-- 定时刷新
CREATE INDEX ON mv_sales_summary(date, customer_id);
REFRESH MATERIALIZED VIEW CONCURRENTLY mv_sales_summary;

-- 分区自动管理
CREATE OR REPLACE FUNCTION create_monthly_partition()
RETURNS void AS $$
DECLARE
    partition_date DATE;
    partition_name TEXT;
BEGIN
    partition_date := DATE_TRUNC('month', CURRENT_DATE + INTERVAL '1 month');
    partition_name := 'sales_orders_' || TO_CHAR(partition_date, 'YYYY_MM');
    
    EXECUTE format(
        'CREATE TABLE IF NOT EXISTS %I PARTITION OF sales_orders
         FOR VALUES FROM (%L) TO (%L)',
        partition_name,
        partition_date,
        partition_date + INTERVAL '1 month'
    );
END;
$$ LANGUAGE plpgsql;

-- 每月1号自动创建下月分区
SELECT cron.schedule('create-partition', '0 0 1 * *', 'SELECT create_monthly_partition()');
```

#### 2. 缓存策略

```javascript
// backend/services/cache/CacheService.js
const Redis = require('ioredis');
const LRU = require('lru-cache');

class CacheService {
  constructor() {
    // L1: 本地缓存
    this.localCache = new LRU({
      max: 1000,
      ttl: 5 * 60 * 1000  // 5分钟
    });

    // L2: Redis集群
    this.redis = new Redis.Cluster([
      { host: 'redis-1', port: 6379 },
      { host: 'redis-2', port: 6379 },
      { host: 'redis-3', port: 6379 }
    ]);
  }

  // 多级缓存获取
  async get(key) {
    // L1缓存
    let value = this.localCache.get(key);
    if (value !== undefined) {
      return value;
    }

    // L2缓存
    value = await this.redis.get(key);
    if (value) {
      value = JSON.parse(value);
      this.localCache.set(key, value);
      return value;
    }

    return null;
  }

  // 多级缓存设置
  async set(key, value, ttl = 3600) {
    this.localCache.set(key, value);
    await this.redis.setex(key, ttl, JSON.stringify(value));
  }

  // 缓存预热
  async warmup() {
    // 预加载热点数据
    const hotMaterials = await db.query(
      'SELECT * FROM materials ORDER BY access_count DESC LIMIT 1000'
    );
    
    for (const material of hotMaterials) {
      await this.set(`material:${material.id}`, material);
    }
  }

  // 缓存失效
  async invalidate(pattern) {
    // 删除本地缓存
    this.localCache.clear();
    
    // 删除Redis缓存
    const keys = await this.redis.keys(pattern);
    if (keys.length > 0) {
      await this.redis.del(...keys);
    }
  }
}

module.exports = new CacheService();
```

#### 3. 连接池优化

```javascript
// backend/config/database.js
const { Pool } = require('pg');

// 主库连接池（写）
const masterPool = new Pool({
  host: 'pg-master.db',
  port: 5432,
  database: 'enterprise_brain',
  user: 'app_user',
  password: process.env.DB_PASSWORD,
  max: 100,  // 最大连接数
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
  // 连接池监控
  log: (msg) => console.log('Master Pool:', msg)
});

// 从库连接池（读）- 3个从库负载均衡
const slavePool = new Pool({
  host: 'pg-slave-lb.db',  // 负载均衡地址
  port: 5432,
  database: 'enterprise_brain',
  user: 'app_user',
  password: process.env.DB_PASSWORD,
  max: 300,  // 读多写少，更多连接
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000
});

module.exports = {
  // 写操作
  async write(sql, params) {
    return await masterPool.query(sql, params);
  },
  
  // 读操作
  async read(sql, params) {
    return await slavePool.query(sql, params);
  },
  
  // 事务
  async transaction(callback) {
    const client = await masterPool.connect();
    try {
      await client.query('BEGIN');
      const result = await callback(client);
      await client.query('COMMIT');
      return result;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }
};
```

---

## 实施路线图

### 第一阶段：基础设施建设 (2-3个月)

```yaml
Week 1-4: 环境搭建
  - [ ] 购买/租用服务器
  - [ ] 搭建Kubernetes集群
  - [ ] 部署PostgreSQL主从集群
  - [ ] 部署Redis集群
  - [ ] 部署消息队列

Week 5-8: 核心服务开发
  - [ ] 用户认证服务
  - [ ] API网关配置
  - [ ] 物料服务重构
  - [ ] BOM服务开发
  - [ ] 订单服务开发

Week 9-12: 数据迁移
  - [ ] SQLite -> PostgreSQL迁移
  - [ ] 数据清洗和验证
  - [ ] 性能基准测试
  - [ ] 灾备演练
```

### 第二阶段：微服务化 (3-4个月)

```yaml
Month 4-5: 服务拆分
  - [ ] 拆分单体应用为微服务
  - [ ] 实现服务注册发现
  - [ ] 配置中心建设
  - [ ] 分布式事务处理

Month 6-7: 平台支持
  - [ ] 开发Electron桌面应用
  - [ ] 优化移动端Uni-App
  - [ ] 开发工控面板UI
  - [ ] 跨平台测试
```

### 第三阶段：性能优化 (2-3个月)

```yaml
Month 8-9: 性能调优
  - [ ] 数据库查询优化
  - [ ] 缓存策略优化
  - [ ] CDN部署
  - [ ] 压力测试

Month 10: 高可用建设
  - [ ] 主备切换
  - [ ] 容灾演练
  - [ ] 监控告警
  - [ ] 自动扩缩容
```

### 第四阶段：上线运营 (1-2个月)

```yaml
Month 11: 试运行
  - [ ] 灰度发布
  - [ ] 部分用户试用
  - [ ] 问题修复
  - [ ] 性能监控

Month 12: 全面上线
  - [ ] 全员培训
  - [ ] 正式上线
  - [ ] 7×24值班
  - [ ] 持续优化
```

---

## 成本预算（年度）

```yaml
硬件成本:
  服务器租赁: ¥3,000,000/年
  带宽网络: ¥600,000/年
  CDN服务: ¥200,000/年
  对象存储: ¥100,000/年
  小计: ¥3,900,000

软件成本:
  Kubernetes商业版: ¥500,000/年
  数据库商业支持: ¥300,000/年
  监控APM工具: ¥200,000/年
  安全防护: ¥400,000/年
  小计: ¥1,400,000

人力成本:
  架构师(1人): ¥600,000/年
  后端工程师(8人): ¥3,200,000/年
  前端工程师(4人): ¥1,200,000/年
  DBA(2人): ¥800,000/年
  运维工程师(4人): ¥1,200,000/年
  测试工程师(2人): ¥500,000/年
  小计: ¥7,500,000

总预算: ¥12,800,000/年

平均每用户成本: ¥1,280/年
```

---

## 附录：快速开始

### 本地开发环境

```bash
# 1. 克隆项目
git clone https://github.com/your-company/enterprise-brain.git
cd enterprise-brain

# 2. 启动基础服务（Docker Compose）
docker-compose -f docker-compose.dev.yml up -d

# 3. 启动后端服务
cd backend
npm install
npm run dev

# 4. 启动前端服务
cd 07-frontend
npm install
npm run dev

# 5. 访问应用
# Web: http://localhost:3018
# API: http://localhost:3005
# Swagger: http://localhost:8080/swagger-ui.html
```

### 生产环境部署

```bash
# 1. 构建Docker镜像
docker build -t enterprise-brain/backend:v1.0.0 ./backend
docker build -t enterprise-brain/frontend:v1.0.0 ./07-frontend

# 2. 推送到镜像仓库
docker push enterprise-brain/backend:v1.0.0
docker push enterprise-brain/frontend:v1.0.0

# 3. 部署到Kubernetes
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/configmap.yaml
kubectl apply -f k8s/secret.yaml
kubectl apply -f k8s/deployment.yaml
kubectl apply -f k8s/service.yaml
kubectl apply -f k8s/ingress.yaml

# 4. 查看部署状态
kubectl get pods -n enterprise-brain
kubectl get svc -n enterprise-brain

# 5. 滚动更新
kubectl set image deployment/material-service material-service=enterprise-brain/material-service:v1.0.1 -n enterprise-brain
```

---

**文档版本**：v2.0（万人企业级）  
**最后更新**：2025-01-30  
**适用规模**：10,000+ 并发用户  
**维护团队**：Enterprise Brain 架构组
