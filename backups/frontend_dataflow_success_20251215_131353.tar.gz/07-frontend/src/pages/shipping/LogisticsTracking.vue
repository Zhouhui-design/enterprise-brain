<template>
  <div class="logistics-tracking-page">
    <h2>发货物流跟踪</h2>
    <p>页面开发中...</p>
  </div>
</template>

<script setup>
// 发货物流跟踪页面
</script>

<style scoped>
.logistics-tracking-page {
  padding: 20px;
}
</style>
