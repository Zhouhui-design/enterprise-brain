<template>
  <div class="shipping-execution-page">
    <h2>发货执行</h2>
    <p>页面开发中...</p>
  </div>
</template>

<script setup>
// 发货执行页面
</script>

<style scoped>
.shipping-execution-page {
  padding: 20px;
}
</style>
