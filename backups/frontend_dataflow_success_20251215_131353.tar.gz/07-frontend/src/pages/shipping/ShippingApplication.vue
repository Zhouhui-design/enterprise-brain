<template>
  <div class="shipping-application-page">
    <h2>发货申请</h2>
    <p>页面开发中...</p>
  </div>
</template>

<script setup>
// 发货申请页面
</script>

<style scoped>
.shipping-application-page {
  padding: 20px;
}
</style>
