<template>
  <div class="delivery-note-page">
    <h2>发货单</h2>
    <p>页面开发中...</p>
  </div>
</template>

<script setup>
// 发货单页面
</script>

<style scoped>
.delivery-note-page {
  padding: 20px;
}
</style>
